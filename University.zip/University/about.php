<?php include 'sub-header.php' ?>
        <div class="sub-header">
            <h1>About Us</h1>
        </div>
</section>

<!------ About Us Section ------>

<section class="about-us">
    <div class="row">
        <div class="about-col">
            <h1>We're the One of the World's Best University</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elif. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <div class="explore-div">
                <button href="" class="submit-button">EXPLORE NOW</button>
            </div>  
        </div>
        <div class="about-col">
            <img src="images/about-us.jpg">
        </div>
    </div>
</section>

<!------ Footer Section ------>

<?php include 'footer.php'; ?>